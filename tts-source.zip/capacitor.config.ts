/**
 * Capacitor configuration for the native Android app «ندای پهلوی».
 * راهنمای کامل فارسی در فایل ANDROID.md آمده است.
 */
const config = {
  appId: "ir.avasaz.app",
  appName: "ندای پهلوی",
  webDir: "out",
  backgroundColor: "#06090e",
  server: {
    androidScheme: "https",
  },
  android: {
    allowMixedContent: false,
  },
};

export default config;
