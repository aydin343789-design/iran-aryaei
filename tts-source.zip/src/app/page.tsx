import Splash from "@/components/Splash";
import Studio from "@/components/Studio";

export default function HomePage() {
  return (
    <>
      <Splash />
      <Studio />
    </>
  );
}
