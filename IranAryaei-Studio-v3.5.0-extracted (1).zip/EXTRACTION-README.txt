# IranAryaei Studio v3.5.0 — APK extraction

این پوشه محتویات بسته APK را بدون تغییر استخراج می‌کند.

نکته مهم:
- فایل‌های وب و قابل‌ویرایش برنامه، در مسیر `assets/public/` قرار دارند؛ از جمله `app.js`، `index.html`، `style.css`، `tts.js` و فایل‌های JSON.
- `classes.dex` کد کامپایل‌شده اندروید است، نه سورس اصلی Java/Kotlin.
- این استخراج به‌تنهایی پروژه کامل Android Studio/Gradle را بازسازی نمی‌کند؛ فایل‌های build، تنظیمات توسعه و تاریخچه Git داخل APK وجود ندارند.
