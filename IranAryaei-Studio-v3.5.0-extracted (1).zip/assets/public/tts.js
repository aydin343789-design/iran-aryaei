/* ==========================================================================
   استودیوی صدا — دقیقاً بر پایهٔ موتور اپلیکیشن «متن به صدا»ی کاربر
   (Piper/VITS فارسی + eSpeak-NG + مسترینگ + MP3) که در voice-engine.js
   از همان فایل‌های TypeScript پروژه بسته‌بندی شده است.
   موتور TextToSpeech اندروید کاملاً حذف شده است.
   ========================================================================== */
(function () {
  'use strict';

  var V = null;
  var state = {
    voiceId: 'female', toneId: 'friendly', rate: 0, pitch: 0,
    humanize: true, breaths: true, warmth: true,
    busy: false, lastBlob: null, lastUrl: null, abort: null
  };

  function q(id) { return document.getElementById(id); }
  function toast(msg) {
    var t = q('toast');
    if (!t) return;
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { t.classList.remove('show'); }, 2800);
  }
  function fa(n) { try { return Number(n).toLocaleString('fa-IR'); } catch (e) { return String(n); } }

  function init() {
    if (!window.VoiceStudio) { toast('موتور صدا بارگذاری نشد'); return; }
    V = window.VoiceStudio;

    var el = {
      text: q('ttsText'), count: q('ttsCount'),
      voices: q('ttsVoices'), tones: q('ttsTones'),
      rate: q('ttsRate'), pitch: q('ttsPitch'),
      rateVal: q('ttsRateVal'), pitchVal: q('ttsPitchVal'),
      humanize: q('optHumanize'), breaths: q('optBreaths'), warmth: q('optWarmth'),
      gen: q('ttsGenerate'), save: q('ttsSave'), share: q('ttsShare'),
      progress: q('ttsProgress'), status: q('ttsStatus'), meta: q('ttsMeta'),
      player: q('ttsPlayer'), play: q('ttsPlay')
    };
    if (!el.text || !el.gen) return;

    function updateCount() {
      var txt = el.text.value || '';
      var words = txt.trim() ? txt.trim().split(/\s+/).length : 0;
      el.count.textContent = fa(txt.length) + ' کاراکتر · ~' + fa(Math.round(words / 2.4)) + ' ثانیه';
    }

    /* ---------- مدل‌های صدا: همراه APK نیستند و در اولین اجرا دانلود می‌شوند ----------
       همان مکانیزم ذخیره‌سازی خودِ موتور (OPFS، پوشهٔ avasaz-voices) استفاده می‌شود،
       پس موتور صدا بدون هیچ تغییری مدل نصب‌شده را می‌خواند. */
    // مدل صدا اول از «ریلیز مخزن خودِ برنامه» دانلود می‌شود؛ اگر آن آماده نبود،
    // منبع اصلی و آینهٔ آن به‌عنوان مسیر دوم و سوم امتحان می‌شوند.
    var REPO_RELEASE = 'https://github.com/aydin343789-design/iran-aryaei/releases/latest/download/';
    function ownRepo(piperId, ext) { return [REPO_RELEASE + piperId + ext]; }

    var OPFS_DIR = 'avasaz-voices';
    var HASHES = {"fa_IR-amir-medium": "fb815380d969ea372b0b21b0de14421f58fe481047e153e69685d079b6e1a9d1", "fa_IR-ganji_adabi-medium": "e9073b41ae65759dcf95778e569c8f3780406dac99549436f6ab8e7d2336ed72", "fa_IR-mana-medium": "e390c0e74ba71fd97c49ba662ee0c6e1724b462ba2d4561698af4f564840f126"};

    function piperFor(id) {
      var list = (V && V.PIPER_VOICES) || [];
      for (var i = 0; i < list.length; i++) { if (list[i].characterId === id) return list[i]; }
      return list[0] || null;
    }
    /* polyfill سبک OPFS روی IndexedDB — برای WebView های قدیمی که
       navigator.storage.getDirectory ندارند. موتور صدا بدون تغییر همین
       API را صدا می‌زند، پس روی این دستگاه‌ها هم کار می‌کند. */
    (function installOpfsPolyfill() {
      try {
        if (navigator.storage && typeof navigator.storage.getDirectory === 'function') return;
      } catch (e) { /* ادامه */ }
      var DB = 'ia-opfs', STORE = 'files';
      function open() {
        return new Promise(function (res, rej) {
          var rq = indexedDB.open(DB, 1);
          rq.onupgradeneeded = function () { rq.result.createObjectStore(STORE); };
          rq.onsuccess = function () { res(rq.result); };
          rq.onerror = function () { rej(rq.error); };
        });
      }
      function tx(mode, fn) {
        return open().then(function (db) {
          return new Promise(function (res, rej) {
            var t = db.transaction(STORE, mode);
            var out = fn(t.objectStore(STORE));
            t.oncomplete = function () { res(out && out.result !== undefined ? out.result : out); };
            t.onerror = function () { rej(t.error); };
            t.onabort = function () { rej(t.error); };
          });
        });
      }
      function fileHandle(path) {
        return {
          kind: 'file',
          name: path.split('/').pop(),
          getFile: function () {
            return tx('readonly', function (s) {
              return s.get(path);
            }).then(function (blob) {
              blob = blob || new Blob([]);
              return new File([blob], path.split('/').pop(), { type: blob.type || '' });
            });
          },
          createWritable: function () {
            var parts = [];
            return Promise.resolve({
              write: function (chunk) {
                parts.push(chunk instanceof Blob ? chunk : new Blob([chunk]));
                return Promise.resolve();
              },
              close: function () {
                return tx('readwrite', function (s) { s.put(new Blob(parts), path); });
              }
            });
          }
        };
      }
      function dirHandle(prefix) {
        return {
          kind: 'directory',
          name: prefix.split('/').filter(Boolean).pop() || '',
          getFileHandle: function (name) { return Promise.resolve(fileHandle(prefix + '/' + name)); },
          getDirectoryHandle: function (name) { return Promise.resolve(dirHandle(prefix + '/' + name)); }
        };
      }
      try {
        if (!navigator.storage) navigator.storage = {};
        navigator.storage.getDirectory = function () { return Promise.resolve(dirHandle('')); };
      } catch (e) { /* بی‌صدا */ }
    })();

    function opfsOk() {
      return !!(navigator.storage && typeof navigator.storage.getDirectory === 'function');
    }
    async function vdir(create) {
      var root = await navigator.storage.getDirectory();
      return root.getDirectoryHandle(OPFS_DIR, { create: !!create });
    }
    async function fsize(dir, name) {
      try { var h = await dir.getFileHandle(name); var f = await h.getFile(); return f.size; }
      catch (e) { return 0; }
    }
    async function voiceReady(v) {
      var pv = piperFor(v && v.id);
      if (!pv || !opfsOk()) return false;
      try {
        var dir = await vdir(false);
        var m = await fsize(dir, pv.piperId + '.onnx');
        var c = await fsize(dir, pv.piperId + '.onnx.json');
        return m >= pv.sizeBytes * 0.95 && c > 100;
      } catch (e) { return false; }
    }
    function hexOf(buf) {
      return Array.prototype.map.call(new Uint8Array(buf), function (b) {
        return ('0' + b.toString(16)).slice(-2);
      }).join('');
    }
    /* ---------- دانلود مدل صدا: اول پل بومی، بعد مسیر وب ----------
       داخل APK، fetch() برای فایل Release گیت‌هاب به دلیل نبود هدر CORS
       شکست می‌خورد و بعضی شبکه‌ها هم دسترسی به huggingface.co را
       می‌بندند. پل بومی با HttpURLConnection دانلود می‌کند (بدون CORS و
       با تغییر مسیر خودکار)، سپس فایل تکه‌تکه به همین‌جا می‌آید و در
       همان حافظه‌ای نوشته می‌شود که موتور صدا می‌خواند (OPFS). موتور
       دست‌نخورده می‌ماند. */
    function nativeBridge() {
      return (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.IranAryaei) || null;
    }
    function cfgUrlsFor(pv) {
      var list = ownRepo(pv.piperId, '.onnx.json');
      if (list.indexOf(pv.configUrl) < 0) list.push(pv.configUrl);
      if (pv.configUrl.indexOf('https://huggingface.co/') === 0) {
        list.push(pv.configUrl.replace('https://huggingface.co/', 'https://hf-mirror.com/'));
      }
      return list;
    }
    function modelUrlsFor(pv) {
      var list = ownRepo(pv.piperId, '.onnx');
      if (list.indexOf(pv.modelUrl) < 0) list.push(pv.modelUrl);
      if (pv.modelUrl.indexOf('https://huggingface.co/') === 0) {
        list.push(pv.modelUrl.replace('https://huggingface.co/', 'https://hf-mirror.com/'));
      }
      return list;
    }
    async function nativePull(urls, cacheName, targetName, dir, expectBytes, onProgress) {
      var p = nativeBridge();
      if (!p || typeof p.downloadUrl !== 'function' || typeof p.readCacheChunk !== 'function') return -1;
      var info = null;
      try { info = await p.downloadUrl({ urls: urls, name: cacheName }); } catch (e) { info = null; }
      if (!info || !info.size) return -1;
      var fh = await dir.getFileHandle(targetName, { create: true });
      var w = await fh.createWritable();
      var off = 0, total = 0, CH = 1024 * 1024;
      try {
        for (;;) {
          var part = null;
          try { part = await p.readCacheChunk({ name: cacheName, offset: off, length: CH }); } catch (e) { break; }
          if (!part || !part.read) break;
          var raw = atob(part.data);
          var u8 = new Uint8Array(raw.length);
          for (var i = 0; i < raw.length; i++) u8[i] = raw.charCodeAt(i);
          await w.write(u8);
          off += part.read; total += part.read;
          if (onProgress && expectBytes) onProgress(Math.min(99, (total / expectBytes) * 100));
        }
      } finally {
        await w.close();
      }
      try { if (p.deleteCacheFile) await p.deleteCacheFile({ name: cacheName }); } catch (e) {}
      if (expectBytes && total < expectBytes * 0.95) {
        throw new Error('دانلود ناقص ماند (' + Math.round(total / 1048576) + ' از ' + Math.round(expectBytes / 1048576) + ' مگابایت) — دوباره تلاش کنید');
      }
      if (!expectBytes && total < 100) throw new Error('فایل تنظیمات مدل دریافت نشد');
      return total;
    }

    async function webPullModel(pv, dir, onProgress) {
      var urls = modelUrlsFor(pv);
      var res = null, lastErr = '';
      for (var ui = 0; ui < urls.length; ui++) {
        try {
          var r0 = await fetch(urls[ui], { cache: 'no-store' });
          if (r0.ok && r0.body) { res = r0; break; }
          lastErr = 'HTTP ' + r0.status;
        } catch (e0) { lastErr = (e0 && e0.message) || 'شبکه'; }
      }
      if (!res) throw new Error('دانلود مدل صدا ناموفق بود (' + lastErr + ')؛ اینترنت را بررسی و دوباره تلاش کنید');
      var total = Number(res.headers.get('content-length')) || pv.sizeBytes;
      var reader = res.body.getReader();
      var parts = [], loaded = 0;
      for (;;) {
        var step = await reader.read();
        if (step.done) break;
        parts.push(step.value);
        loaded += step.value.length;
        onProgress(Math.min(99, (loaded / total) * 100));
      }
      if (loaded < pv.sizeBytes * 0.95) {
        throw new Error('دانلود ناقص ماند؛ اتصال اینترنت را بررسی و دوباره تلاش کنید');
      }
      var blob = new Blob(parts);
      var want = HASHES[pv.piperId];
      if (want) {
        var buf = await blob.arrayBuffer();
        var got = hexOf(await crypto.subtle.digest('SHA-256', buf));
        if (got !== want) throw new Error('فایل مدل صدا سالم نیست (checksum نمی‌خواند) — دوباره تلاش کنید');
        blob = new Blob([buf]);
      }
      var mh = await dir.getFileHandle(pv.piperId + '.onnx', { create: true });
      var mw = await mh.createWritable(); await mw.write(blob); await mw.close();
    }

    async function webPullCfg(pv, dir) {
      var urls = cfgUrlsFor(pv);
      var cfgBlob = null;
      for (var ci = 0; ci < urls.length; ci++) {
        try { var cr0 = await fetch(urls[ci], { cache: 'no-store' }); if (cr0.ok) { cfgBlob = await cr0.blob(); break; } } catch (e1) {}
      }
      if (!cfgBlob) throw new Error('دانلود تنظیمات صدا ناموفق بود — اینترنت را بررسی کنید');
      var ch = await dir.getFileHandle(pv.piperId + '.onnx.json', { create: true });
      var cw = await ch.createWritable(); await cw.write(cfgBlob); await cw.close();
    }

    async function installVoice(v, onProgress) {
      var pv = piperFor(v.id);
      if (!pv) throw new Error('مدل این صدا تعریف نشده است');
      if (!opfsOk()) throw new Error('حافظهٔ داخلی برنامه در این دستگاه پشتیبانی نمی‌شود');
      var dir = await vdir(true);
      onProgress(1);

      // ۱) تنظیمات مدل (کوچک) — اول بومی، بعد وب
      var gotCfg = -1;
      try { gotCfg = await nativePull(cfgUrlsFor(pv), 'cfg-' + pv.piperId + '.json', pv.piperId + '.onnx.json', dir, 0, null); } catch (eC) { gotCfg = -1; }
      if (gotCfg < 0) await webPullCfg(pv, dir);
      onProgress(4);

      // ۲) خود مدل (~۶۱ مگابایت) — اول بومی، بعد وب
      var gotModel = -1;
      try { gotModel = await nativePull(modelUrlsFor(pv), 'model-' + pv.piperId + '.onnx', pv.piperId + '.onnx', dir, pv.sizeBytes, onProgress); } catch (eM) { gotModel = -1; }
      if (gotModel < 0) await webPullModel(pv, dir, onProgress);

      try { await navigator.storage.persist(); } catch (e) {}
      onProgress(100);
    }

    function renderVoices() {
      el.voices.innerHTML = '';
      V.VOICES.forEach(function (v) {
        var b = document.createElement('button');
        b.className = 'voice-card' + (state.voiceId === v.id ? ' active' : '');
        b.innerHTML = '<div class="voice-avatar">' +
          (v.id === 'female' ? '👩' : v.id === 'male' ? '🧑' : '🧔') + '</div>' +
          '<div class="voice-info"><div class="voice-name">' + v.name + '</div>' +
          '<div class="voice-title">' + v.title + '</div>' +
          '<div class="voice-desc">' + v.desc + '</div>' +
          '<div class="voice-state" id="vstate-' + v.id + '">بررسی…</div></div>';
        b.addEventListener('click', function () { state.voiceId = v.id; renderVoices(); });
        el.voices.appendChild(b);
        refreshVoiceState(v);
      });
    }

    async function refreshVoiceState(v) {
      var node = q('vstate-' + v.id);
      if (!node) return;
      var ok = await voiceReady(v);
      node.className = 'voice-state ' + (ok ? 'ready' : 'need');
      if (ok) { node.textContent = '✅ آماده — آفلاین'; node.onclick = null; return; }
      node.textContent = '⬇️ دانلود این صدا (۶۱ مگابایت)';
      node.onclick = function (ev) {
        if (ev) { ev.stopPropagation(); ev.preventDefault(); }
        downloadVoiceFor(v);
      };
    }
    async function downloadFor(v, onTick) {
      var pv = piperFor(v.id);
      try {
        await installVoice(v, function (p) { if (onTick) onTick(p); });
        toast('صدای «' + v.name + '» نصب شد و از این پس آفلاین کار می‌کند');
        refreshVoiceState(v);
        return true;
      } catch (e) {
        toast((e && e.message) || 'دانلود صدا ناموفق بود');
        refreshVoiceState(v);
        return false;
      }
    }
    async function downloadVoiceFor(v) {
      var node = q('vstate-' + v.id);
      if (node) { node.className = 'voice-state need'; node.textContent = 'دانلود ۰٪'; }
      await downloadFor(v, function (p) {
        if (node) node.textContent = 'دانلود ' + Math.round(p) + '٪';
      });
    }
    async function ensureVoiceReady() {
      var vdef = null;
      for (var i = 0; i < V.VOICES.length; i++) {
        if (V.VOICES[i].id === state.voiceId) { vdef = V.VOICES[i]; break; }
      }
      if (!vdef) vdef = V.VOICES[0];
      if (await voiceReady(vdef)) return true;
      var naam = vdef.name;
      setStatus('اولین بار: دانلود مدل صدای «' + naam + '»…');
      var ok = await downloadFor(vdef, function (p) {
        setProgress(p / 100);
        setStatus('دانلود مدل صدای «' + naam + '» — ' + Math.round(p) + '٪');
      });
      if (!ok) { setStatus('مدل صدا نصب نشد — دکمهٔ دانلود همان صدا را بزنید تا پیام دقیق خطا را ببینید'); setProgress(0); return false; }
      return true;
    }



    function renderTones() {
      el.tones.innerHTML = '';
      V.TONES.forEach(function (t) {
        var b = document.createElement('button');
        b.className = 'tone-chip' + (state.toneId === t.id ? ' active' : '');
        b.textContent = t.title;
        b.title = t.desc;
        b.addEventListener('click', function () { state.toneId = t.id; renderTones(); });
        el.tones.appendChild(b);
      });
    }

    el.text.addEventListener('input', updateCount);
    updateCount();

    el.rate.addEventListener('input', function () {
      state.rate = parseInt(el.rate.value, 10);
      el.rateVal.textContent = (1 + state.rate / 50).toFixed(1).replace('.', '٫') + '×';
    });
    el.pitch.addEventListener('input', function () {
      state.pitch = parseInt(el.pitch.value, 10);
      el.pitchVal.textContent = (state.pitch > 0 ? '+' : '') + fa(state.pitch);
    });

    ['humanize', 'breaths', 'warmth'].forEach(function (k) {
      var box = el[k];
      if (!box) return;
      box.checked = state[k];
      box.addEventListener('change', function () { state[k] = box.checked; });
    });

    var clr = q('ttsClear'), smp = q('ttsSample'), pst = q('ttsPaste');
    if (clr) clr.addEventListener('click', function () { el.text.value = ''; updateCount(); });
    if (smp) smp.addEventListener('click', function () {
      el.text.value = 'هر کس در این جهان، داستانی دارد که تنها خودش می‌داند. صدای تو، بلندترین صدای جهان است؛ فقط باید باور کنی که شنیده می‌شود.';
      updateCount();
    });
    if (pst) pst.addEventListener('click', async function () {
      try {
        var t = await navigator.clipboard.readText();
        if (t) { el.text.value += t; updateCount(); } else toast('کلیپ‌بورد خالی است');
      } catch (e) { toast('دسترسی به کلیپ‌بورد مجاز نشد'); }
    });

    function setProgress(f) { if (el.progress) el.progress.style.width = Math.round(f * 100) + '%'; }
    function setStatus(s) { if (el.status) el.status.textContent = s; }

    el.gen.addEventListener('click', async function () {
      var text = el.text.value.trim();
      if (!text) { toast('اول متن را بنویسید'); return; }
      if (state.busy) { if (state.abort) state.abort.abort(); return; }

      if (!(await ensureVoiceReady())) { toast('مدل صدا آماده نشد'); return; }

      state.busy = true;
      el.gen.textContent = '✕ لغو';
      el.gen.classList.add('busy');
      setProgress(0.01);
      setStatus('در حال آماده‌سازی…');
      state.abort = new AbortController();

      try {
        var res = await V.generateSpeech({
          text: text, voiceId: state.voiceId, toneId: state.toneId,
          rate: state.rate, pitch: state.pitch,
          humanize: state.humanize, breaths: state.breaths, warmth: state.warmth
        }, function (p) { setProgress(p.fraction); setStatus(p.label); }, state.abort.signal);

        if (state.lastUrl) { try { URL.revokeObjectURL(state.lastUrl); } catch (e) {} }
        state.lastBlob = res.blob;
        state.lastUrl = URL.createObjectURL(res.blob);
        el.player.src = state.lastUrl;
        el.player.classList.remove('hidden');
        el.play.classList.remove('hidden');
        // ریشهٔ «دکمه پیدا نمی‌شود»: کانتینر #ttsActions با کلاس hidden می‌ماند،
        // پس هر سه دکمه (پخش/ذخیره/اشتراک) هرگز روی صفحه نمی‌آمدند و کلیک
        // کاربر هیچ‌وقت به مسیر ذخیره نمی‌رسید.
        var acts = q('ttsActions');
        if (acts) acts.classList.remove('hidden');
        if (el.save) el.save.classList.remove('hidden');
        if (el.share) el.share.classList.remove('hidden');
        setProgress(1);
        setStatus('آماده است');
        el.meta.textContent = 'مدت: ' + fa(Math.round(res.durationSec)) + ' ثانیه · حجم: ' +
          (res.sizeBytes / 1048576).toFixed(2).replace('.', '٫') + ' مگابایت · MP3';
        try { await el.player.play(); } catch (e) {}
      } catch (err) {
        var msg = (err && err.message) ? err.message : 'خطا در ساخت صدا';
        if (msg === 'CANCELLED') { setStatus('لغو شد'); toast('ساخت صدا لغو شد'); }
        else { setStatus('خطا'); toast(msg); }
      } finally {
        state.busy = false;
        el.gen.textContent = '🎧 ساخت صدا';
        el.gen.classList.remove('busy');
        state.abort = null;
      }
    });

    if (el.play) el.play.addEventListener('click', function () {
      if (!el.player.src) return;
      if (el.player.paused) el.player.play(); else el.player.pause();
    });
    if (el.player) {
      el.player.addEventListener('play', function () { if (el.play) el.play.textContent = '⏸ توقف موقت'; });
      el.player.addEventListener('pause', function () { if (el.play) el.play.textContent = '▶ پخش'; });
    }


    /* ================= ذخیرهٔ فایل صوتی =================
       ابزارهای دیگر از این مسیر ذخیره می‌کنند و همه‌شان در پوشهٔ
       «Download/Iran Aryaei» موفق‌اند: ابتدا فایل موقت با
       writeTempFile ساخته می‌شود، بعد saveTempFile آن را با MediaStore
       در همان پوشه می‌نشاند. بخش صدا از این مسیر استفاده نمی‌کرد و
       مسیر جداگانهٔ خودش را داشت که شکست می‌خورد و پیام هم نمی‌داد.
       حالا صدا هم دقیقاً همین مسیر را می‌رود؛ در صورت شکست، دو مسیر
       پشتیبان و پیام خطای واقعی روی صفحه می‌آید. */
    function nativePlugin() {
      return (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.IranAryaei) || null;
    }
    function b64Of(blob) {
      return new Promise(function (resolve, reject) {
        var reader = new FileReader();
        reader.onload = function () {
          var s = String(reader.result || '');
          var i = s.indexOf(',');
          resolve(i >= 0 ? s.slice(i + 1) : s);
        };
        reader.onerror = function () { reject(reader.error || new Error('خواندن فایل ناموفق بود')); };
        reader.readAsDataURL(blob);
      });
    }
    async function saveAudio(blob, name, say) {
      var errors = [];
      var plugin = nativePlugin();

      // مسیر ۱ — همان کمکیِ ابزارهای سالم
      if (plugin && typeof blob !== 'undefined' && blob && blob.size) {
        try {
          if (say) say('آماده‌سازی فایل…');
          var b64 = await b64Of(blob);
          var wr = await plugin.writeTempFile({ name: name, data: b64 });
          if (!wr || !wr.path) throw new Error('فایل موقت ساخته نشد');
          if (say) say('نوشتن در پوشهٔ دانلودها…');
          var sv = await plugin.saveTempFile({ path: wr.path, name: name, mime: blob.type || 'audio/mpeg' });
          if (!sv || !sv.uri) throw new Error('ذخیره در دانلودها نشانی برنگرداند');
          return { ok: true, path: 'Download/Iran Aryaei/' + (sv.name || name), uri: sv.uri, size: blob.size };
        } catch (e1) {
          errors.push('دانلودها: ' + ((e1 && e1.message) || e1));
        }
      } else {
        errors.push('دانلودها: پلاگین بومی در دسترس نیست');
      }

      // مسیر ۲ — پل تکه‌تکهٔ IranSaver (بدون محدودیت حجم پل)
      var saver = window.IranSaver;
      if (saver && typeof saver.begin === 'function') {
        try {
          var HEAD = 128 * 1024;
          var r0 = String(saver.begin(name));
          if (r0.indexOf('ERR|') === 0) throw new Error(r0.slice(4));
          for (var o = 0; o < blob.size; o += HEAD) {
            var part = await b64Of(blob.slice(o, Math.min(blob.size, o + HEAD)));
            var rr = String(saver.append(part));
            if (rr.indexOf('ERR|') === 0) throw new Error(rr.slice(4));
            if (say) say('ذخیره ' + Math.round(Math.min(99, (o + HEAD) / blob.size * 100)) + '٪');
          }
          var fin = String(saver.finish(blob.type || 'audio/mpeg'));
          if (fin.indexOf('ERR|') === 0) throw new Error(fin.slice(4));
          var seg = fin.split('|');
          return { ok: true, path: seg[1] || name, size: blob.size };
        } catch (e2) {
          errors.push('IranSaver: ' + ((e2 && e2.message) || e2));
        }
      } else {
        errors.push('IranSaver: در دسترس نیست');
      }

      // مسیر ۳ — پنجرهٔ ذخیرهٔ سیستم (مستقل از مجوز و MediaStore)
      if (saver && typeof saver.pickSave === 'function') {
        try {
          var pick = String(saver.pickSave(blob.type || 'audio/mpeg'));
          if (pick === 'PENDING') {
            if (say) say('پنجرهٔ ذخیره باز شد؛ مقصد را انتخاب کنید…');
            var got = await new Promise(function (resolve) {
              var done = false;
              window.__iaSaved = function (p) { if (!done) { done = true; window.__iaSaved = null; resolve(p || ''); } };
              setTimeout(function () { if (!done) { done = true; window.__iaSaved = null; resolve(''); } }, 180000);
            });
            if (got) return { ok: true, path: got, size: blob.size };
            errors.push('پنجرهٔ ذخیره: مقصدی انتخاب نشد');
          } else {
            errors.push('پنجرهٔ ذخیره: ' + pick);
          }
        } catch (e3) {
          errors.push('پنجرهٔ ذخیره: ' + ((e3 && e3.message) || e3));
        }
      }
      return { ok: false, error: errors.join(' | ') };
    }

    function fileName() { return 'iran-aryaei-' + Date.now() + '.mp3'; }
    if (el.save) el.save.addEventListener('click', async function () {
      if (!state.lastBlob) { toast('اول صدا را بسازید'); return; }
      var name = fileName();
      var label = el.save.innerHTML;
      el.save.disabled = true;
      function say(msg) {
        el.save.textContent = '⏳ ' + msg;
        if (el.meta) el.meta.textContent = msg;
        setStatus(msg);
      }
      try {
        var res = await saveAudio(state.lastBlob, name, say);
        if (res && res.ok) {
          if (el.meta) el.meta.textContent = '✔ ذخیره شد در: ' + res.path;
          setStatus('✔ ذخیره شد در: ' + res.path);
          toast('فایل صوتی ذخیره شد: ' + res.path);
        } else {
          var em = (res && res.error) || 'خطای ناشناخته';
          if (el.meta) el.meta.textContent = '✖ ذخیره نشد — ' + em;
          setStatus('✖ ذخیره نشد');
          toast('ذخیره نشد: ' + em);
        }
      } catch (err) {
        var m = (err && err.message) ? err.message : 'خطای ذخیره';
        if (el.meta) el.meta.textContent = '✖ ذخیره نشد — ' + m;
        setStatus('✖ ذخیره نشد');
        toast('ذخیره نشد: ' + m);
      } finally {
        el.save.disabled = false;
        el.save.innerHTML = label;
      }
    });
    if (el.share) el.share.addEventListener('click', function () {
      if (!state.lastBlob) return;
      if (window.IranAryaeiShareBlob) window.IranAryaeiShareBlob(state.lastBlob, fileName(), 'audio/mpeg');
      else toast('اشتراک‌گذاری در دسترس نیست');
    });

    renderVoices();
    renderTones();
    setStatus('آماده است');
    if (el.meta) el.meta.textContent = 'آماده است — بعد از ساخت صدا دکمهٔ «ذخیره» فایل را در Download/Iran Aryaei می‌گذارد.';
  }

  window.TTSStudio = { init: init, toast: toast };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else setTimeout(init, 0);
})();
